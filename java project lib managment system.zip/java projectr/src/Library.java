import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Library {
    private List<Book> books;
    private static final String FILE_NAME = "library_books.ser";

    public Library() {
        books = new ArrayList<>();
        loadBooks(); // Load from file on initialization
    }

    public void addBook(Book book) {
        books.add(book);
        saveBooks();
        System.out.println("Book added: " + book);
    }

    public void removeBook(String isbn) {
        Book bookToRemove = searchBookByIsbn(isbn);
        if (bookToRemove != null) {
            books.remove(bookToRemove);
            saveBooks();
            System.out.println("Book removed: " + bookToRemove);
        } else {
            System.out.println("Book not found with ISBN: " + isbn);
        }
    }

    public Book searchBookByIsbn(String isbn) {
        for (Book book : books) {
            if (book.getIsbn().equals(isbn)) {
                return book;
            }
        }
        return null;
    }

    public List<Book> searchBooksByTitle(String title) {
        List<Book> results = new ArrayList<>();
        for (Book book : books) {
            if (book.getTitle().toLowerCase().contains(title.toLowerCase())) {
                results.add(book);
            }
        }
        return results;
    }

    public void borrowBook(String isbn) {
        Book book = searchBookByIsbn(isbn);
        if (book != null && book.isAvailable()) {
            book.setAvailable(false);
            saveBooks();
            System.out.println("Book borrowed: " + book);
        } else if (book != null) {
            System.out.println("Book is not available: " + book);
        } else {
            System.out.println("Book not found with ISBN: " + isbn);
        }
    }

    public void returnBook(String isbn) {
        Book book = searchBookByIsbn(isbn);
        if (book != null && !book.isAvailable()) {
            book.setAvailable(true);
            saveBooks();
            System.out.println("Book returned: " + book);
        } else if (book != null) {
            System.out.println("Book is already available: " + book);
        } else {
            System.out.println("Book not found with ISBN: " + isbn);
        }
    }

    public void displayAllBooks() {
        if (books.isEmpty()) {
            System.out.println("No books in the library.");
        } else {
            for (Book book : books) {
                System.out.println(book);
            }
        }
    }

    private void saveBooks() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(books);
        } catch (IOException e) {
            System.out.println("Error saving books: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void loadBooks() {
        File file = new File(FILE_NAME);
        if (file.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
                books = (List<Book>) ois.readObject();
            } catch (IOException | ClassNotFoundException e) {
                System.out.println("Error loading books: " + e.getMessage());
            }
        }
    }
}