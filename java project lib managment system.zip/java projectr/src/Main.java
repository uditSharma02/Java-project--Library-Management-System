import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\nLibrary Management System");
            System.out.println("1. Add Book");
            System.out.println("2. Remove Book");
            System.out.println("3. Search Book by ISBN");
            System.out.println("4. Search Books by Title");
            System.out.println("5. Borrow Book");
            System.out.println("6. Return Book");
            System.out.println("7. Display All Books");
            System.out.println("8. Exit");
            System.out.print("Choose an option: ");

            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    System.out.print("Enter title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter author: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter ISBN: ");
                    String isbn = scanner.nextLine();
                    library.addBook(new Book(title, author, isbn));
                    break;
                case 2:
                    System.out.print("Enter ISBN to remove: ");
                    isbn = scanner.nextLine();
                    library.removeBook(isbn);
                    break;
                case 3:
                    System.out.print("Enter ISBN to search: ");
                    isbn = scanner.nextLine();
                    Book book = library.searchBookByIsbn(isbn);
                    if (book != null) {
                        System.out.println("Found: " + book);
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;
                case 4:
                    System.out.print("Enter title keyword: ");
                    title = scanner.nextLine();
                    List<Book> results = library.searchBooksByTitle(title);
                    if (results.isEmpty()) {
                        System.out.println("No books found.");
                    } else {
                        for (Book b : results) {
                            System.out.println(b);
                        }
                    }
                    break;
                case 5:
                    System.out.print("Enter ISBN to borrow: ");
                    isbn = scanner.nextLine();
                    library.borrowBook(isbn);
                    break;
                case 6:
                    System.out.print("Enter ISBN to return: ");
                    isbn = scanner.nextLine();
                    library.returnBook(isbn);
                    break;
                case 7:
                    library.displayAllBooks();
                    break;
                case 8:
                    running = false;
                    System.out.println("Exiting system.");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
        scanner.close();
    }
}